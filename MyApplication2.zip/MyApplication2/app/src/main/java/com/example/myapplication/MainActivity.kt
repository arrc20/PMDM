package com.example.myapplication

import android.os.AsyncTask
import android.os.Bundle
import android.util.Log
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var dogListView: ListView
    private lateinit var searchEditText: EditText
    private lateinit var searchButton: Button
    private lateinit var ratingBar: RatingBar
    private lateinit var voteButton: Button
    private lateinit var dogImageView: ImageView

    private lateinit var dogAdapter: ArrayAdapter<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        dogImageView = findViewById(R.id.dogImageView)
        dogListView = findViewById(R.id.dogListView)
        searchEditText = findViewById(R.id.searchEditText)
        searchButton = findViewById(R.id.searchButton)
        ratingBar = findViewById(R.id.ratingBar)
        voteButton = findViewById(R.id.voteButton)

        dogAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1)
        dogListView.adapter = dogAdapter

        searchButton.setOnClickListener {
            val breed = searchEditText.text.toString().trim()
            Log.d("MainActivity", "Breed to search: $breed")
            FetchDogImagesTask().execute(breed)
        }

        voteButton.setOnClickListener {
            val rating = ratingBar.rating
            // Implementa aquí tu lógica de votación
            Toast.makeText(this, "Voted: $rating stars", Toast.LENGTH_SHORT).show()
        }
    }

    private inner class FetchDogImagesTask : AsyncTask<String, Void, List<String>?>() {

        override fun doInBackground(vararg params: String): List<String>? {
            val breed = params[0]
            try {
                val apiUrl = URL("https://dog.ceo/api/breed/$breed/images/random/5")
                Log.d("FetchDogImagesTask", "API URL: $apiUrl")

                val connection = apiUrl.openConnection() as HttpURLConnection
                val responseCode = connection.responseCode
                Log.d("FetchDogImagesTask", "Response Code: $responseCode")

                if (responseCode == HttpURLConnection.HTTP_OK) {
                    val inputStream: InputStream = connection.inputStream
                    val scanner = Scanner(inputStream).useDelimiter("\\A")
                    val result = if (scanner.hasNext()) scanner.next() else null

                    Log.d("FetchDogImagesTask", "API Response: $result")

                    return parseImageUrls(result)
                } else if (responseCode == HttpURLConnection.HTTP_NOT_FOUND) {
                    // Manejar el caso cuando la raza no es encontrada
                    Log.e("FetchDogImagesTask", "Breed not found")
                    return null
                } else {
                    // Manejar el código de estado no esperado aquí
                    Log.e("FetchDogImagesTask", "Unexpected Response Code: $responseCode")
                    return null
                }
            } catch (e: IOException) {
                e.printStackTrace()
                Log.e("FetchDogImagesTask", "Error fetching data", e)
                return null
            }
        }

        override fun onPostExecute(result: List<String>?) {
            super.onPostExecute(result)
            if (result != null) {
                updateDogList(result)
            } else {
                // Mostrar mensaje de Toast con sugerencias si la raza no es encontrada
                val suggestedBreeds = listOf("husky", "goldenretriever", "beagle") // Agrega más razas sugeridas si es necesario
                val suggestionMessage = if (suggestedBreeds.isNotEmpty()) {
                    "Suggested breeds: ${suggestedBreeds.joinToString(", ")}"
                } else {
                    ""
                }
                Toast.makeText(this@MainActivity, "Breed not found. $suggestionMessage", Toast.LENGTH_SHORT).show()
            }
        }

        private fun parseImageUrls(result: String?): List<String> {
            val imageUrls = mutableListOf<String>()
            try {
                val json = JSONObject(result)
                if (json.has("message")) {
                    val jsonArray: JSONArray = json.optJSONArray("message") ?: JSONArray()
                    for (i in 0 until jsonArray.length()) {
                        val imageUrl = jsonArray.getString(i)
                        imageUrls.add(imageUrl)
                    }
                } else {
                    // Agregado para manejar un formato inesperado de la respuesta
                    Log.e("FetchDogImagesTask", "Unexpected JSON format: $result")
                }
            } catch (e: JSONException) {
                e.printStackTrace()
            }
            return imageUrls
        }

        private fun updateDogList(imageUrls: List<String>) {
            dogAdapter.clear()
            dogAdapter.addAll(imageUrls)
            dogAdapter.notifyDataSetChanged()

            // Mostrar la primera imagen en ImageView (opcional)
            if (imageUrls.isNotEmpty()) {
                Glide.with(this@MainActivity).load(imageUrls[0]).into(dogImageView)
            }
        }
    }
}

